# Taskit — HTML package

Static, framework-free front end for the Taskit decluttering coach. No build step:
open `index.html` in a browser. Nothing is wired to a camera, network or model —
every hook is marked so you can connect it to your own architecture.

## Files

| File | Screen |
|---|---|
| `index.html` | Welcome — "Take a photo of your space" / "Choose from library" |
| `analyzing.html` | Calm waiting state with rotating reassurance lines |
| `session.html` | Core loop: photo left / coach chat right (stacks on phones) |
| `done.html` | Finished for today · `done.html?state=paused` for stopping early |
| `assets/css/taskit.css` | All tokens and components, light + dark |
| `assets/js/session-ui.js` | Session UI controller → `window.TaskitSession` |
| `assets/js/demo-coach.js` | Mock coach that drives the UI. **Delete when wiring.** |
| `assets/img/sample-room.svg`, `sample-closeup.svg` | Placeholder photos |

Search for `WIRE:` comments in the HTML for hook points. Elements you'll likely
bind to carry `data-tk="…"` attributes (stable selectors; class names are for styling).

## Session API (`window.TaskitSession`)

All boxes are **normalized to the photo, 0–1, origin top-left**: `{ x, y, w, h }`.
Your model's pixel boxes divide by the image width/height.

```js
const S = window.TaskitSession;

// Photo
S.setPhoto(src, { width, height, closeup })   // aspect ratio from width/height (or read from the image)
S.showStep({ title, pill?, outlines: [{x,y,w,h}, …] })  // red outlines + un-blurred window
S.showCloser({ title, pill?, frame: {x,y,w,h} })        // corner brackets + "Take a closer photo"
S.toggleZoom(force?)
S.setPhotoCollapsed(bool)                     // phone: compact strip

// Chat (all text is set with textContent — safe for model output)
S.addCoach(text)
S.addUser(text)
S.addUserPhoto(src, caption?)
S.addTask({ title, body, label?, kind: 'step' | 'closer' })
S.addCelebrate(text)                          // e.g. "2 steps done"
S.addSupport()                                // 988 card (see template #tk-tpl-support)
S.setQuickReplies([{ id, label, variant?: 'primary'|'secondary', icon?: 'check'|'camera', href? }])
S.clearLog()

// Chrome
S.setProgress({ stepsDone, minutes })         // shows steps finished + soft time vs ~15 min, no countdown
S.setGear('Gloves & mask')                    // null hides the chip

// Events
S.on('reply',     ({ id, label, event }) => …)  // quick-reply tapped
S.on('message',   ({ text }) => …)              // free text sent
S.on('takePhoto', () => …)                      // open the camera, then setPhoto(..., {closeup:true})
S.on('pause',     ({ event }) => …)             // "I'm done for today" (link to done.html by default)
S.on('zoom',      ({ zoomed }) => …)
```

Minimal loop:

```js
S.on('reply', async ({ id, label }) => {
  S.addUser(label);
  const next = await yourCoach.reply(id);           // your backend
  next.messages.forEach(S.addCoach);
  if (next.task) { S.addTask(next.task); S.showStep(next.task); }
  S.setQuickReplies(next.replies);
});
```

Review states without a backend: `session.html?demo=closer`, `?demo=closeup`, `?demo=support`.

`analyzing.html` exposes `window.TaskitAnalyzing.setPhoto(src)` and `.ready()`
(remove the 20-second demo timer at the bottom of the file).

## Design rules baked in

- **Red (`--tk-focus`) is only for photo outlines.** Buttons, errors and badges never use it.
- One step at a time: no room-wide lists, counts of what's left, or scores.
- "Pause · I'm done for today" is always visible in the top bar.
- Copy avoids "hoard", "mess", "junk", "dirty", "gross" and "trash".
- Tap targets ≥ 44px (most are 52px). Light and dark follow the OS; force with
  `<html data-theme="light|dark">`. `prefers-reduced-motion` turns off animation.
- Layout: two panels above 820px wide; stacked (photo on top, collapsible) below.

## Notes

- Fonts load from Google Fonts (Newsreader, Figtree), with system fallbacks. Self-host if needed.
- The support card links to call/text 988, 988lifeline.org/chat and findahelpline.com.
  Have someone confirm these fit your audience before shipping.
- Uses modern CSS (container query units, `color-mix`, `dvh`); current evergreen browsers.
