/* ==========================================================================
   Taskit — DEMO coach (mock data only)
   Shows how to drive window.TaskitSession. Replace this file with calls from
   your backend / model. Nothing here touches the network or the camera.

   Jump straight to a state with a query string:
     session.html?demo=closer   – the "take a closer photo" variant
     session.html?demo=closeup  – after the closer photo arrives
     session.html?demo=support  – the support moment
   ========================================================================== */
(function () {
  'use strict';
  const S = window.TaskitSession;

  // Sample photo is 1200×900; helper converts pixel boxes to normalized ones.
  const n = (x, y, w, h, W = 1200, H = 900) => ({ x: x / W, y: y / H, w: w / W, h: h / H });

  const STEPS = [
    { title: 'The cups on the side table',
      outlines: [n(165, 406, 88, 74), n(256, 413, 80, 67), n(338, 400, 90, 80)],
      body: 'Carry these three cups to the kitchen sink. No need to wash them yet — just move them.',
      smaller: 'Carry just one cup to the sink. One is enough.',
      where: 'The sink is perfect for now. If one belongs on a shelf instead, that works too — whatever feels easiest.' },
    { title: 'The clothes on the chair', intro: 'Next, something soft.',
      outlines: [n(512, 436, 268, 154)],
      body: 'Fold them loosely and set them on the bed. If something needs a wash, the laundry basket works too.',
      smaller: 'Pick up just the top piece and fold it. That’s the whole step.',
      where: 'The bed or a laundry basket is fine. They don’t need to be put away perfectly today.' },
    { title: 'The papers by the table', intro: 'Here’s a quick one.',
      outlines: [n(108, 686, 336, 132)],
      body: 'Gather them into one pile and set it on the table. No reading or sorting today — just one pile.',
      smaller: 'Pick up just the top three papers and set them on the table.',
      where: 'Right on the table is perfect. We can look through them another day, if you like.' },
    { title: 'The corner by the window', closer: true, frame: n(826, 446, 318, 256),
      intro: 'The boxes by the window are hard for me to make out from here.',
      body: 'Could you take a closer photo of just that corner? About an arm’s length away is perfect.',
      smaller: 'Just the top of the stack is enough for a photo.',
      where: 'Nothing needs to move here yet — I only need a closer look.' },
    { title: 'The small box on top', intro: 'Thank you — that’s much clearer.',
      photo: 'assets/img/sample-closeup.svg',
      outlines: [n(98, 78, 144, 114, 440, 330)],
      body: 'Lift the small box off the stack and set it on the floor beside you. You can open the flaps and take a peek. Nothing has to leave.',
      smaller: 'Just open the flaps. You don’t need to lift it.',
      where: 'On the floor beside you is fine — it’s only for a peek.' }
  ];

  const MINUTES = [0, 4, 7, 10, 12, 14, 15];
  const PAUSE = { id: 'pause', label: 'Pause for today', href: 'done.html?state=paused' };
  const REPLIES = {
    normal: [{ id: 'done', label: 'Done', variant: 'primary', icon: 'check' }, { id: 'else', label: 'Something else' }],
    else: [{ id: 'swap', label: 'Try a different step' }, { id: 'toomuch', label: 'This feels like too much' },
           { id: 'where', label: 'Where do these go?' }, { id: 'back', label: 'Back to this step' }],
    gentle: [{ id: 'tiny', label: 'Make it tiny', variant: 'primary' }, PAUSE],
    support: [{ id: 'keep', label: 'Keep going, gently', variant: 'primary' }, { id: 'minute', label: 'I need a minute' }, PAUSE],
    closer: [{ id: 'take-photo', label: 'Take closer photo', variant: 'primary', icon: 'camera' }, { id: 'skip', label: 'Skip this area' }],
    end: [{ id: 'finish', label: 'Finish for today', variant: 'primary', href: 'done.html' }]
  };

  let step = 0, done = 0;
  const cur = () => STEPS[step];
  const modeFor = () => (cur().closer ? 'closer' : 'normal');
  const replies = (mode) => S.setQuickReplies(REPLIES[mode]);
  const progress = () => S.setProgress({ stepsDone: done, minutes: MINUTES[Math.min(done, 6)] });

  function present(st) {
    if (st.photo) S.setPhoto(st.photo, { width: 1200, height: 900, closeup: true });
    if (st.closer) S.showCloser({ title: st.title, frame: st.frame });
    else S.showStep({ title: st.title, outlines: st.outlines });
  }

  function next() {
    step++;
    if (step >= STEPS.length) { step = STEPS.length - 1; return end(); }
    const st = cur();
    S.addCoach(st.closer ? st.intro : `${st.intro} I’ve outlined it on your photo.`);
    S.addTask({ title: st.title, body: st.body, kind: st.closer ? 'closer' : 'step' });
    present(st);
    replies(modeFor());
  }

  function end() {
    S.addCoach('That’s a lovely place to stop. You did real, careful work today.');
    replies('end');
  }

  function classify(text) {
    const s = text.toLowerCase();
    if (/(ashamed|hate myself|hate that|hopeless|worthless|can.?t go on|want to die|kill myself|don.?t want to be here)/.test(s)) return 'distress';
    if (/(too much|overwhelm|can.?t do this)/.test(s)) return 'toomuch';
    if (/(let (it|this|them|these) go|can.?t let|keep (it|this|them)|part with|get rid)/.test(s)) return 'letgo';
    if (/(where|put (it|them|these))/.test(s)) return 'where';
    if (/^(done|finished|did it)/.test(s)) return 'done';
    return 'other';
  }

  function handle(id, { typed = false, label } = {}) {
    if (!typed && label && id !== 'take-photo') S.addUser(label);
    switch (id) {
      case 'done':
        done++;
        S.addCelebrate(done === 1 ? 'First step done' : `${done} steps done`);
        progress(); next(); break;
      case 'else': S.addCoach('Of course. What would help right now?'); replies('else'); break;
      case 'swap': S.addCoach('Sure — we can leave that one for another day.'); next(); break;
      case 'back': S.addCoach('Okay. Take your time, and tap Done whenever you’re ready.'); replies(modeFor()); break;
      case 'toomuch':
        S.addCoach('Thank you for telling me. That feeling makes a lot of sense, and it doesn’t mean you’re doing anything wrong.');
        S.addCoach('We can stop right here — starting today already counts. Or we can make this step tiny.');
        replies('gentle'); break;
      case 'tiny':
      case 'keep':
        S.addCoach(id === 'tiny' ? 'Okay. Even smaller:' : 'Okay. We’ll keep it small:');
        S.addTask({ title: cur().title, body: cur().smaller, kind: cur().closer ? 'closer' : 'step' });
        replies(modeFor()); break;
      case 'where': S.addCoach(cur().where); replies(modeFor()); break;
      case 'letgo': S.addCoach('That’s okay. Nothing has to leave today. This step is only about moving things, not deciding about them.'); replies(modeFor()); break;
      case 'distress':
        S.addCoach('Thank you for telling me. Shame is heavy to carry, and you don’t have to carry it alone. Nothing in this photo says anything about your worth.');
        S.addCoach('If today feels heavy, it can help to talk with someone:');
        S.addSupport();
        S.addCoach(done === 0 ? 'We can also stop here. Opening Taskit today already counts.'
          : `We can also stop here. You’ve already done ${done === 1 ? 'one step' : done + ' steps'} today, and that counts.`);
        replies('support'); break;
      case 'minute': S.addCoach('Take all the time you need. I’m right here whenever you’re ready.'); replies(modeFor()); break;
      case 'take-photo':
        // Your app opens the camera here, then calls S.setPhoto(newSrc, {closeup:true}) and shows the next step.
        if (!cur().closer) return;
        step++;
        S.addUserPhoto(cur().photo);
        S.addCoach(`${cur().intro} I’ve outlined the next step on your new photo.`);
        S.addTask({ title: cur().title, body: cur().body });
        present(cur());
        replies('normal'); break;
      case 'skip': S.addCoach('Of course — that corner can wait for another day.'); end(); break;
      default: S.addCoach('Thanks for telling me. Would you like to keep going with this step, or try something else?'); replies(modeFor());
    }
  }

  S.on('reply', ({ id, label }) => { if (!['pause', 'finish'].includes(id)) handle(id, { label }); });
  S.on('takePhoto', () => handle('take-photo'));
  S.on('message', ({ text }) => { S.addUser(text); handle(classify(text), { typed: true }); });

  // ---- Opening message ----
  S.setGear('Gloves & mask');
  progress();
  S.addCoach('Hi, I’m really glad you’re here. We’ll go one small step at a time, and you can stop whenever you like. Stopping counts, every time.');
  S.addCoach('One gentle note: there may be some dust near the boxes, so gloves and a mask could make things more comfortable. I’ve pinned a reminder up top.');
  S.addCoach('Here’s your first step. I’ve outlined it on your photo.');
  S.addTask({ title: STEPS[0].title, body: STEPS[0].body });
  present(STEPS[0]);
  replies('normal');

  // ---- Deep links for review ----
  const demo = new URLSearchParams(location.search).get('demo');
  if (demo === 'closer' || demo === 'closeup') { handle('done', { label: 'Done' }); handle('done', { label: 'Done' }); handle('done', { label: 'Done' }); }
  if (demo === 'closeup') handle('take-photo');
  if (demo === 'support') {
    handle('done', { label: 'Done' });
    const t = 'honestly I feel so ashamed. I hate that I let it get like this.';
    S.addUser(t); handle(classify(t), { typed: true });
  }
})();
